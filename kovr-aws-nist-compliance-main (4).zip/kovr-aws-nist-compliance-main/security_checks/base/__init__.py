"""Base classes for security checks."""

from .base_check import BaseSecurityCheck

__all__ = ["BaseSecurityCheck"]